'''
Name: Rokaya Waleed Mohamed.
ID: 692400090.
Group: B3.
'''

def fcfs(processes):
    processes.sort(key=lambda p: p["arrival"])
    time = 0
    results = []

    for p in processes:
        if time < p["arrival"]:
            time = p["arrival"]
        start = time
        time += p["burst"]
        turnaround = time - p["arrival"]
        waiting = turnaround - p["burst"]
        results.append({**p, "start": start, "finish": time,
                        "turnaround": turnaround, "waiting": waiting})

    print(f"\n{'Process':<10} {'Arrival':>7} {'Burst':>7} {'Start':>7} {'Finish':>8} {'Turnaround':>12} {'Waiting':>9}")
    print("-" * 64)
    for r in results:
        print(f"{r['name']:<10} {r['arrival']:>7} {r['burst']:>7} {r['start']:>7} {r['finish']:>8} {r['turnaround']:>12} {r['waiting']:>9}")

    print(f"\nAverage Waiting Time    : {sum(r['waiting'] for r in results) / len(results):.2f}ms")
    print(f"Average Turnaround Time : {sum(r['turnaround'] for r in results) / len(results):.2f}ms")

'''
Project OS Scheduling Algorithms - Multi Level Queue GUI
Uses: fcfs.py, RoundRobin.py, sjf_non_preemptive.py, highest_priority_first.py

Names: {Abdelrhman Hussien, Rokaya Waleed, Omar Mohamed, Hana Ahmed}
IDs: {692400340, 692400090, 692400319, 692400501}
Groups: {A2, B3, A2, A2}
'''

import tkinter as tk
from tkinter import ttk, messagebox
import sys, os, io

# ── Import the four algorithm modules ──────────────────────────────────────────
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fcfs import fcfs
from RoundRobin import round_robin
from sjf_non_preemptive import sjf_non_preemptive
from highest_priority_first import hpf_non_preemptive

# ══════════════════════════════════════════════════════════════════════════════
# Colour palette & fonts
# ══════════════════════════════════════════════════════════════════════════════
BG        = "#0D1117"
PANEL     = "#161B22"
BORDER    = "#30363D"
ACCENT    = "#58A6FF"
ACCENT2   = "#3FB950"
ACCENT3   = "#F78166"
TEXT      = "#E6EDF3"
SUBTEXT   = "#8B949E"
ENTRY_BG  = "#21262D"
HEADER_BG = "#1C2128"

FONT_TITLE  = ("Courier New", 22, "bold")
FONT_HEAD   = ("Courier New", 11, "bold")
FONT_BODY   = ("Courier New", 10)
FONT_SMALL  = ("Courier New",  9)
FONT_LABEL  = ("Courier New", 10)
FONT_MONO   = ("Courier New", 10)


# ══════════════════════════════════════════════════════════════════════════════
# Helper – compute Response Time (first time CPU was given)
# We wrap each algorithm and capture the moment each process first started.
# ══════════════════════════════════════════════════════════════════════════════

def run_algorithm(algo_name, processes, quantum=2):
    """
    Run the selected algorithm and return a list of result dicts with keys:
    name, arrival, burst, priority(if HPF), start, finish,
    turnaround, waiting, response
    Also returns the captured console output (Gantt-style log for RR).
    """
    # Capture stdout printed by the algorithms
    buf = io.StringIO()
    old_stdout = sys.stdout
    sys.stdout = buf

    results = []

    if algo_name == "FCFS":
        procs = [dict(p) for p in processes]
        fcfs(procs)
        # Rebuild results from what fcfs computed (it sorts by arrival)
        procs2 = sorted([dict(p) for p in processes], key=lambda p: p["arrival"])
        time = 0
        for p in procs2:
            if time < p["arrival"]:
                time = p["arrival"]
            start  = time
            time  += p["burst"]
            tat    = time - p["arrival"]
            wt     = tat  - p["burst"]
            rt     = start - p["arrival"]
            results.append({**p, "start": start, "finish": time,
                            "turnaround": tat, "waiting": wt, "response": rt})

    elif algo_name == "Round Robin":
        procs = sorted([dict(p) for p in processes], key=lambda p: p["arrival"])
        round_robin(procs, quantum)
        # Recompute with response-time tracking
        remaining = [p["burst"] for p in procs]
        finish    = [0]  * len(procs)
        first_run = [-1] * len(procs)
        time = 0
        while any(r > 0 for r in remaining):
            for i, p in enumerate(procs):
                if remaining[i] > 0:
                    if first_run[i] == -1:
                        first_run[i] = time
                    run = min(quantum, remaining[i])
                    time += run
                    remaining[i] -= run
                    if remaining[i] == 0:
                        finish[i] = time
        for i, p in enumerate(procs):
            tat = finish[i] - p["arrival"]
            wt  = tat - p["burst"]
            rt  = first_run[i] - p["arrival"]
            results.append({**p, "start": first_run[i], "finish": finish[i],
                            "turnaround": tat, "waiting": wt, "response": rt})

    elif algo_name == "SJF (Non-Preemptive)":
        procs = [dict(p) for p in processes]
        sjf_non_preemptive(procs)
        remaining2 = [dict(p) for p in processes]
        time2 = 0
        while remaining2:
            available = [p for p in remaining2 if p["arrival"] <= time2]
            if not available:
                time2 = min(p["arrival"] for p in remaining2)
                available = [p for p in remaining2 if p["arrival"] <= time2]
            p = min(available, key=lambda p: (p["burst"], p.get("pid", p.get("name",""))))
            remaining2.remove(p)
            start  = time2
            time2 += p["burst"]
            tat    = time2 - p["arrival"]
            wt     = tat - p["burst"]
            rt     = start - p["arrival"]
            results.append({**p, "start": start, "finish": time2,
                            "turnaround": tat, "waiting": wt, "response": rt})

    elif algo_name == "HPF (Non-Preemptive)":
        procs = [dict(p) for p in processes]
        hpf_non_preemptive(procs)
        remaining3 = [dict(p) for p in processes]
        time3 = 0
        while remaining3:
            available = [p for p in remaining3 if p["arrival"] <= time3]
            if not available:
                time3 = min(p["arrival"] for p in remaining3)
                available = [p for p in remaining3 if p["arrival"] <= time3]
            p = max(available, key=lambda p: (p["priority"], -p.get("pid", 0)))
            remaining3.remove(p)
            start  = time3
            time3 += p["burst"]
            tat    = time3 - p["arrival"]
            wt     = tat - p["burst"]
            rt     = start - p["arrival"]
            results.append({**p, "start": start, "finish": time3,
                            "turnaround": tat, "waiting": wt, "response": rt})

    sys.stdout = old_stdout
    console_out = buf.getvalue()
    return results, console_out


# ══════════════════════════════════════════════════════════════════════════════
# Process-input dialog
# ══════════════════════════════════════════════════════════════════════════════

class ProcessInputDialog(tk.Toplevel):
    def __init__(self, parent, n, algo, quantum_var):
        super().__init__(parent)
        self.title("Enter Process Details")
        self.configure(bg=BG)
        self.resizable(False, False)
        self.grab_set()

        self.algo       = algo
        self.n          = n
        self.quantum    = quantum_var
        self.processes  = None
        self.need_pid   = algo in ("SJF (Non-Preemptive)", "HPF (Non-Preemptive)")
        self.need_prio  = algo == "HPF (Non-Preemptive)"
        self.use_name   = algo in ("FCFS", "Round Robin")

        self._build(n)
        self.wait_window()

    # ── layout ────────────────────────────────────────────────────────────────
    def _build(self, n):
        pad = dict(padx=14, pady=6)

        # Title bar
        tk.Label(self, text=f"  {self.algo}  —  {n} Processes",
                bg=HEADER_BG, fg=ACCENT, font=FONT_HEAD,
                anchor="w", pady=10).pack(fill="x")

        frame = tk.Frame(self, bg=BG)
        frame.pack(fill="both", expand=True, padx=18, pady=10)

        # Column headers
        cols = ["#", "Name/ID", "Arrival", "Burst"]
        if self.need_prio:
            cols.append("Priority")

        for c, h in enumerate(cols):
            tk.Label(frame, text=h, bg=BG, fg=ACCENT, font=FONT_HEAD,
                    width=10).grid(row=0, column=c, pady=(0,6))

        self.entries = []
        for i in range(n):
            row_entries = {}
            tk.Label(frame, text=f"P{i+1}", bg=BG, fg=SUBTEXT,
                    font=FONT_LABEL, width=10).grid(row=i+1, column=0)

            # Name/ID entry
            e_name = tk.Entry(frame, bg=ENTRY_BG, fg=TEXT, font=FONT_BODY,
                            insertbackground=TEXT, width=10,
                            relief="flat", highlightthickness=1,
                            highlightcolor=ACCENT, highlightbackground=BORDER)
            e_name.insert(0, f"P{i+1}" if self.use_name else str(i+1))
            e_name.grid(row=i+1, column=1, padx=4, pady=3)
            row_entries["name_id"] = e_name

            # Arrival
            e_arr = tk.Entry(frame, bg=ENTRY_BG, fg=TEXT, font=FONT_BODY,
                            insertbackground=TEXT, width=10,
                            relief="flat", highlightthickness=1,
                            highlightcolor=ACCENT, highlightbackground=BORDER)
            e_arr.insert(0, "0")
            e_arr.grid(row=i+1, column=2, padx=4, pady=3)
            row_entries["arrival"] = e_arr

            # Burst
            e_bst = tk.Entry(frame, bg=ENTRY_BG, fg=TEXT, font=FONT_BODY,
                            insertbackground=TEXT, width=10,
                            relief="flat", highlightthickness=1,
                            highlightcolor=ACCENT, highlightbackground=BORDER)
            e_bst.grid(row=i+1, column=3, padx=4, pady=3)
            row_entries["burst"] = e_bst

            # Priority (HPF only)
            if self.need_prio:
                e_pri = tk.Entry(frame, bg=ENTRY_BG, fg=TEXT, font=FONT_BODY,
                                insertbackground=TEXT, width=10,
                                relief="flat", highlightthickness=1,
                                highlightcolor=ACCENT, highlightbackground=BORDER)
                e_pri.insert(0, "1")
                e_pri.grid(row=i+1, column=4, padx=4, pady=3)
                row_entries["priority"] = e_pri

            self.entries.append(row_entries)

        # Quantum row (Round Robin only)
        if self.algo == "Round Robin":
            qf = tk.Frame(self, bg=BG)
            qf.pack(pady=(0, 4))
            tk.Label(qf, text="Time Quantum:", bg=BG, fg=ACCENT,
                    font=FONT_LABEL).pack(side="left", padx=(0,8))
            eq = tk.Entry(qf, bg=ENTRY_BG, fg=TEXT, font=FONT_BODY,
                        insertbackground=TEXT, width=8,
                        relief="flat", highlightthickness=1,
                        highlightcolor=ACCENT, highlightbackground=BORDER)
            eq.insert(0, str(self.quantum))
            eq.pack(side="left")
            self.e_quantum = eq

        # Buttons
        bf = tk.Frame(self, bg=BG)
        bf.pack(fill="x", padx=18, pady=12)
        tk.Button(bf, text="  Run  ", bg=ACCENT, fg=BG, font=FONT_HEAD,
                relief="flat", cursor="hand2",
                command=self._submit).pack(side="right", padx=6)
        tk.Button(bf, text="Cancel", bg=BORDER, fg=TEXT, font=FONT_LABEL,
                relief="flat", cursor="hand2",
                command=self.destroy).pack(side="right")

    # ── validation & submit ───────────────────────────────────────────────────
    def _submit(self):
        processes = []
        for i, row in enumerate(self.entries):
            try:
                arrival = float(row["arrival"].get())
                burst   = float(row["burst"].get())
            except ValueError:
                messagebox.showerror("Input Error",
                    f"Row {i+1}: Arrival and Burst must be numbers.", parent=self)
                return
            if burst <= 0:
                messagebox.showerror("Input Error",
                    f"Row {i+1}: Burst must be > 0.", parent=self)
                return

            p = {"arrival": arrival, "burst": burst}

            if self.use_name:
                p["name"] = row["name_id"].get().strip() or f"P{i+1}"
            else:
                try:
                    p["pid"] = int(row["name_id"].get())
                except ValueError:
                    p["pid"] = i + 1

            if self.need_prio:
                try:
                    p["priority"] = int(row["priority"].get())
                except ValueError:
                    messagebox.showerror("Input Error",
                        f"Row {i+1}: Priority must be an integer.", parent=self)
                    return

            processes.append(p)

        if self.algo == "Round Robin":
            try:
                q = int(self.e_quantum.get())
                if q <= 0:
                    raise ValueError
                self.quantum = q
            except ValueError:
                messagebox.showerror("Input Error",
                    "Time Quantum must be a positive integer.", parent=self)
                return

        self.processes = processes
        self.destroy()


# ══════════════════════════════════════════════════════════════════════════════
# Main Application Window
# ══════════════════════════════════════════════════════════════════════════════

class OSSchedulerApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("OS Scheduler — Multi Level Queue")
        self.configure(bg=BG)
        self.geometry("1000x700")
        self.minsize(900, 600)

        self._quantum = 2
        self._build_ui()

    # ── top banner ────────────────────────────────────────────────────────────
    def _build_ui(self):
        # Header
        hdr = tk.Frame(self, bg=HEADER_BG, pady=14)
        hdr.pack(fill="x")
        tk.Label(hdr, text="⚙  OS PROCESS SCHEDULER",
                bg=HEADER_BG, fg=ACCENT, font=FONT_TITLE,
                anchor="w", padx=24).pack(side="left")
        tk.Label(hdr, text="Multi-Level Queue Simulator",
                bg=HEADER_BG, fg=SUBTEXT, font=FONT_SMALL,
                anchor="e", padx=24).pack(side="right")

        # Separator
        tk.Frame(self, bg=ACCENT, height=2).pack(fill="x")

        # Controls bar
        ctrl = tk.Frame(self, bg=PANEL, pady=10)
        ctrl.pack(fill="x")

        tk.Label(ctrl, text="Algorithm:", bg=PANEL, fg=TEXT,
                font=FONT_LABEL, padx=16).pack(side="left")

        self.algo_var = tk.StringVar(value="FCFS")
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("Custom.TCombobox",
                        fieldbackground=ENTRY_BG,
                        background=ENTRY_BG,
                        foreground=TEXT,
                        selectbackground=ACCENT,
                        selectforeground=BG,
                        arrowcolor=ACCENT,
                        bordercolor=BORDER)
        combo = ttk.Combobox(ctrl, textvariable=self.algo_var,
                            values=["FCFS","Round Robin",
                                    "SJF (Non-Preemptive)","HPF (Non-Preemptive)"],
                            state="readonly", width=22,
                            style="Custom.TCombobox", font=FONT_BODY)
        combo.pack(side="left", padx=4)

        tk.Label(ctrl, text="Processes:", bg=PANEL, fg=TEXT,
                font=FONT_LABEL, padx=12).pack(side="left")
        self.n_var = tk.StringVar(value="3")
        n_spin = tk.Spinbox(ctrl, from_=1, to=20, textvariable=self.n_var,
                            width=4, bg=ENTRY_BG, fg=TEXT,
                            buttonbackground=BORDER, relief="flat",
                            font=FONT_BODY, insertbackground=TEXT)
        n_spin.pack(side="left")

        run_btn = tk.Button(ctrl, text="  ▶  RUN  ",
                            bg=ACCENT2, fg=BG, font=FONT_HEAD,
                            relief="flat", cursor="hand2",
                            padx=8, command=self._open_input)
        run_btn.pack(side="left", padx=18)

        clear_btn = tk.Button(ctrl, text="Clear",
                            bg=BORDER, fg=TEXT, font=FONT_LABEL,
                            relief="flat", cursor="hand2",
                            command=self._clear)
        clear_btn.pack(side="left")

        # ── Main content: results table + stats ───────────────────────────────
        content = tk.Frame(self, bg=BG)
        content.pack(fill="both", expand=True, padx=18, pady=12)

        # Table frame
        tframe = tk.Frame(content, bg=PANEL, bd=0,
                        highlightthickness=1, highlightbackground=BORDER)
        tframe.pack(fill="both", expand=True)

        # Table header label
        tk.Label(tframe, text="  Results", bg=HEADER_BG, fg=ACCENT,
                font=FONT_HEAD, anchor="w", pady=6).pack(fill="x")

        # Treeview
        tree_scroll = tk.Scrollbar(tframe)
        tree_scroll.pack(side="right", fill="y")

        cols = ("Process","Arrival","Burst","Priority",
                "Start","Finish","Turnaround","Waiting","Response")
        self.tree = ttk.Treeview(tframe, columns=cols, show="headings",
                                yscrollcommand=tree_scroll.set,
                                height=12)
        tree_scroll.config(command=self.tree.yview)

        style.configure("Treeview",
                        background=PANEL, foreground=TEXT,
                        fieldbackground=PANEL, rowheight=28,
                        font=FONT_MONO)
        style.configure("Treeview.Heading",
                        background=HEADER_BG, foreground=ACCENT,
                        font=FONT_HEAD, relief="flat")
        style.map("Treeview",
                background=[("selected", ACCENT)],
                foreground=[("selected", BG)])

        widths = {"Process":90,"Arrival":80,"Burst":70,"Priority":75,
                "Start":70,"Finish":70,"Turnaround":100,"Waiting":80,"Response":90}
        for c in cols:
            self.tree.heading(c, text=c)
            self.tree.column(c, width=widths[c], anchor="center")

        self.tree.pack(fill="both", expand=True, padx=4, pady=4)
        self.tree.tag_configure("even", background="#1C2128")
        self.tree.tag_configure("odd",  background=PANEL)

        # ── Stats bar ─────────────────────────────────────────────────────────
        stats_frame = tk.Frame(self, bg=HEADER_BG,
                            highlightthickness=1,
                            highlightbackground=BORDER)
        stats_frame.pack(fill="x", padx=18, pady=(0,14))

        tk.Label(stats_frame, text="  Averages:", bg=HEADER_BG,
                fg=SUBTEXT, font=FONT_HEAD, pady=8).pack(side="left")

        self.lbl_awt = self._stat_label(stats_frame, "Avg Waiting",    "—")
        self.lbl_att = self._stat_label(stats_frame, "Avg Turnaround", "—")
        self.lbl_art = self._stat_label(stats_frame, "Avg Response",   "—")

        # Console output area (for Round Robin log)
        self.console_frame = tk.Frame(self, bg=BG)
        self.console_frame.pack(fill="x", padx=18, pady=(0,10))

        self.console_label = tk.Label(self.console_frame,
                                    text="", bg=BG, fg=SUBTEXT,
                                    font=FONT_SMALL, justify="left",
                                    anchor="w")
        self.console_label.pack(fill="x")

    def _stat_label(self, parent, title, value):
        f = tk.Frame(parent, bg=HEADER_BG, padx=20)
        f.pack(side="left")
        tk.Label(f, text=title, bg=HEADER_BG, fg=SUBTEXT,
                font=FONT_SMALL).pack()
        lbl = tk.Label(f, text=value, bg=HEADER_BG, fg=ACCENT2,
                    font=FONT_HEAD)
        lbl.pack()
        return lbl

    # ── actions ───────────────────────────────────────────────────────────────
    def _open_input(self):
        try:
            n = int(self.n_var.get())
            if n < 1:
                raise ValueError
        except ValueError:
            messagebox.showerror("Error", "Number of processes must be ≥ 1.")
            return

        algo = self.algo_var.get()
        dlg  = ProcessInputDialog(self, n, algo, self._quantum)

        if dlg.processes is None:
            return  # cancelled

        if algo == "Round Robin":
            self._quantum = dlg.quantum

        self._display_results(algo, dlg.processes)

    def _display_results(self, algo, processes):
        results, console_out = run_algorithm(algo, processes, self._quantum)

        # Clear tree
        for item in self.tree.get_children():
            self.tree.delete(item)

        # Hide priority column unless HPF
        show_prio = algo == "HPF (Non-Preemptive)"
        self.tree.column("Priority", width=75 if show_prio else 0,
                        minwidth=0 if not show_prio else 75)

        total_wt = total_tat = total_rt = 0

        for idx, r in enumerate(sorted(results,
                key=lambda x: x.get("pid", x.get("name","")))):
            name = r.get("name", f"P{r.get('pid','?')}")
            prio = r.get("priority", "—") if show_prio else "—"
            tag  = "even" if idx % 2 == 0 else "odd"
            self.tree.insert("", "end", tags=(tag,), values=(
                name,
                f"{r['arrival']:.1f}",
                f"{r['burst']:.1f}",
                str(prio),
                f"{r['start']:.1f}",
                f"{r['finish']:.1f}",
                f"{r['turnaround']:.1f}",
                f"{r['waiting']:.1f}",
                f"{r['response']:.1f}",
            ))
            total_wt  += r["waiting"]
            total_tat += r["turnaround"]
            total_rt  += r["response"]

        n = len(results)
        self.lbl_awt.config(text=f"{total_wt/n:.2f} ms")
        self.lbl_att.config(text=f"{total_tat/n:.2f} ms")
        self.lbl_art.config(text=f"{total_rt/n:.2f} ms")

        # Show RR log if any
        if algo == "Round Robin" and console_out.strip():
            lines = [l for l in console_out.split("\n") if "→" in l]
            preview = "\n".join(lines[:6])
            if len(lines) > 6:
                preview += f"\n  … and {len(lines)-6} more slices"
            self.console_label.config(
                text="  Execution Log (Round Robin):\n" + preview)
        else:
            self.console_label.config(text="")

    def _clear(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        self.lbl_awt.config(text="—")
        self.lbl_att.config(text="—")
        self.lbl_art.config(text="—")
        self.console_label.config(text="")


# ══════════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    app = OSSchedulerApp()
    app.mainloop()
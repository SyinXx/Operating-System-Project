'''
Name: Hana Ahmed
ID: 692400501
Group: A2
'''

def sjf_non_preemptive(processes):
    remaining = processes[:]
    time = 0
    results = []

    while remaining:
        available = [p for p in remaining if p["arrival"] <= time]
        if not available:
            time = min(p["arrival"] for p in remaining)
            available = [p for p in remaining if p["arrival"] <= time]

        p = min(available, key=lambda p: (p["burst"], p["pid"]))
        remaining.remove(p)

        start      = time
        time      += p["burst"]
        turnaround = time - p["arrival"]
        waiting    = turnaround - p["burst"]
        results.append({**p, "start": start, "finish": time,
                        "turnaround": turnaround, "waiting": waiting})

    print(f"\n{'PID':<6} {'Arrival':>8} {'Burst':>7} {'Start':>7} {'Finish':>8} {'Turnaround':>12} {'Waiting':>9}")
    print("-" * 61)
    for r in sorted(results, key=lambda x: x["pid"]):
        print(f"P{r['pid']:<5} {r['arrival']:>8.1f} {r['burst']:>7.1f} {r['start']:>7.1f} "
            f"{r['finish']:>8.1f} {r['turnaround']:>12.1f} {r['waiting']:>9.1f}")

    n = len(results)
    print(f"\nAverage Waiting Time    : {sum(r['waiting'] for r in results) / n:.2f}ms")
    print(f"Average Turnaround Time : {sum(r['turnaround'] for r in results) / n:.2f}ms")
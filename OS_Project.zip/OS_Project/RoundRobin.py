'''
Name: Abdelrhman Hussien.
ID: 692400340.
Group: A2.
'''

def round_robin(processes, quantum):
    processes.sort(key=lambda p: p["arrival"])
    remaining = [p["burst"] for p in processes]
    finish = [0] * len(processes)
    time = 0

    while any(r > 0 for r in remaining):
        for i, p in enumerate(processes):
            if remaining[i] > 0:
                run = min(quantum, remaining[i])
                print(f"  Time {time:>4}ms → {time + run:>4}ms : {p['name']} runs ({run}ms)")
                time += run
                remaining[i] -= run
                if remaining[i] == 0:
                    finish[i] = time

    print(f"\n{'Process':<10} {'Arrival':>7} {'Burst':>7} {'Finish':>8} {'Turnaround':>12} {'Waiting':>9}")
    print("-" * 57)
    total_wt = total_tat = 0
    for i, p in enumerate(processes):
        tat = finish[i] - p["arrival"]
        wt  = tat - p["burst"]
        total_tat += tat
        total_wt  += wt
        print(f"{p['name']:<10} {p['arrival']:>7} {p['burst']:>7} {finish[i]:>8} {tat:>12} {wt:>9}")

    n = len(processes)
    print(f"\nAverage Waiting Time    : {total_wt / n:.2f}ms")
    print(f"Average Turnaround Time : {total_tat / n:.2f}ms")